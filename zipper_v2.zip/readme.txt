Das mit dem brutforce funktioniert irgendwie nicht so richtig. Ich weiss nicht genau an was es liegt.
Ich würde bei der Presentation sagen, dass dies der einzige logische weg ist das passwort mit [libzip] abzufragen.
Also die Funktion zip_fopen_index_encrypted zu verwerden. Es tut mir wirklich leid aber ich habe nicht wirklich herausgefunden an was es liegt.
Vielleicht hat es etwas mit dem Verschlüsselungsstandard zu tun. Wenn Ihr das morgen herausfindet wäre ich froh wenn ihr mir es auch sagen könnte.


Compilieren des Programs:

make /* das program wird compiliert und die executable findest du dann in ./bin/zipper */

make install /* das program wird im installiert jetzt kannst du es im terminal so ausführen [zipper -o test.zip] */

make remove /* deinstalliert das programm wieder */

Funktionen:

-> option -h --help

exapmle:
zipper -h

output:
-h, --help	Show this help
-o, --open	Open a zip file for browsing
-b, --bruteforce	Try to bruteforce the password
-d, --dictionary [FILE]	Try to bruteforce the password with a dictionary
-p, --password [PASSWORD]	Use this password
-e, --extract [FILE]	Extract this file
-i, --include [FILE]	Include this file

-> option -o --open

example:
zipper -o test.zip

output:
Actions:
extract file or directory(e), visit directory(v), go back(b), open file(o), quit(q)
./
1. dir1/
2. dir2/
3. file1
4. file2

example:
with input e2 you can export dir2 the full folder
or you can export with example e4 the file2

with v[index] you can visit directory and the content of it shows up
with b you can go back

with o you can show the file content in the terminal


-> option -b

example:
zipper -b pass.zip /* pass.zip is encrypted */

-> option -d

exmaple:
zipper -b -d dictionary pass.zip /* goes thrue the dictionary file and try the passwords in it */

-> option -e

example:
zipper -e extract test.zip /* extracts the full zip archive into the extract folder location */

-> option -i
zipper -i src test.zip /* adds the complete src folder in to the test.zip */

