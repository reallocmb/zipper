#include<stdio.h>
#include<stdlib.h>
#include<getopt.h>
#include"ziply.h"

int main(int argc, char **argv)
{
    struct option long_options[] = {
        { "help", no_argument, 0, 'h' },
        { "open", no_argument, 0, 'o' },
        { "bruteforce", no_argument, 0, 'b' },
        { "dictionary", required_argument, 0, 'd' },
        { "password", required_argument, 0, 'p' },
        { "extract", required_argument, 0, 'e' },
        { "include", required_argument, 0, 'i' },
    };

    int option_index = 0;
    char c;

    void (*ziply_function)(void) = NULL;

    while ((c = getopt_long(argc, argv, "hobd:p:e:i:", long_options, &option_index)) != -1) {
        switch (c) {
            case 0:
                if (long_options[option_index].flag != 0)
                    break;
                printf("option %s", long_options[option_index].name);
                if (optarg)
                    printf(" with arg %s", optarg);
                putchar('\n');
                break;
    
            case 'h':
                puts("Usage zipper [OPTIONS] [ZIP_FILE]");
                printf("-%c, --%s\t%s\n", (char)long_options[0].val, long_options[0].name, "Show this help");
                printf("-%c, --%s\t%s\n", (char)long_options[1].val, long_options[1].name, "Open a zip file for browsing");
                printf("-%c, --%s\t%s\n", (char)long_options[2].val, long_options[2].name, "Try to bruteforce the password");
                printf("-%c, --%s [FILE]\t%s\n", (char)long_options[3].val, long_options[3].name, "Try to bruteforce the password with a dictionary");
                printf("-%c, --%s [PASSWORD]\t%s\n", (char)long_options[4].val, long_options[4].name, "Use this password");
                printf("-%c, --%s [FILE]\t%s\n", (char)long_options[5].val, long_options[5].name, "Extract this file");
                printf("-%c, --%s [FILE]\t%s\n", (char)long_options[6].val, long_options[6].name, "Include this file");
                return 0;
            case 'o':
                ziply_function = ziply_browse;
                break;
            case 'b':
                ziply_function = ziply_bruteforce;
                break;
            case 'd':
                ziply_zipobject_argument_set(optarg);
                break;
            case 'p':
                ziply_zipobject_argument_set(optarg);
                ziply_function = ziply_password;
                break;
            case 'e':
                ziply_zipobject_argument_set(optarg);
                ziply_function = ziply_extract;
                break;
            case 'i':
                ziply_zipobject_argument_set(optarg);
                ziply_function = ziply_include;
                break;
            case '?':
                printf("%d\n", option_index);
                printf("%c\n", (char)optopt);
                break;
        }
    }

    int diff = argc - optind;
    if (diff == 1) {
        ziply_zipobject_path_zip_file_set(argv[optind]);
    }

    if (diff > 1) {
        printf("diff error\n");
    }

    if (diff <= 0) {
        puts("missing [ZIP_FILE] argument");
        printf("Usage zipper [OPTIONS] [ZIP_FILE]\n");
    }

    if (ziply_function) {
        ziply_function();
    }

    return EXIT_SUCCESS;
}
