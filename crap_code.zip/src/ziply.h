#ifndef ZIPLY_H
#define ZIPLY_H

char *ziply_zipobject_path_zip_file_get(void);
char *ziply_zipobject_argument_get(void);

void ziply_zipobject_path_zip_file_set(char *path_zip_file);
void ziply_zipobject_argument_set(char *argument);

void ziply_browse(void);

void ziply_bruteforce(void);

void ziply_password(void);
void ziply_extract(void);
void ziply_include(void);

#endif
