#include<stdio.h>
#include<stdlib.h>
#include<zip.h>
#include<string.h>
#include<stdbool.h>
#include<sys/stat.h>
#include<dirent.h>

struct {
    char *path_zip_file;
    char *argument;
} ZipObject = { NULL, NULL };

char *ziply_zipobject_path_zip_file_get(void)
{
    return ZipObject.path_zip_file;
}

char *ziply_zipobject_argument_get(void)
{
    return ZipObject.argument;
}

void ziply_zipobject_path_zip_file_set(char *path_zip_file)
{
    ZipObject.path_zip_file = path_zip_file;
}

void ziply_zipobject_argument_set(char *argument)
{
    ZipObject.argument = argument;
}

void directory_change(char **current_directory, const char *new_directory) {
    *current_directory = (char *)new_directory;
}

void directory_back(char **current_directory)
{
    char *new_path;
    /* src/bin/ */
    int len = strlen(*current_directory);

    int i;
    for (i = len - 2; (*current_directory)[i] != '/'; i--) {
        if (i == 0) {
            new_path = malloc(sizeof(*current_directory));;
            new_path[0] = 0;
            *current_directory = new_path;
            return;
        }
    }

    new_path = malloc(i + 2 * sizeof(*new_path));
    strncpy(new_path, *current_directory, i + 1);
    new_path[i + 1] = 0;
    *current_directory = new_path;
}

void print_first_directory(zip_t *archive, int *indexes, int entries_count) {
    int i;
    int k;
    for (i = 0, k = 1; i < entries_count; ++i) {
        const char *filename = zip_get_name(archive, i, 0);
        char *ptr = strchr(filename, '/');

        if (ptr == NULL || *(ptr + 1) == 0) {
            printf("%d: %s\n", k, filename);
            indexes[k - 1] = i;
            k++;
        }
    }
}


void print_directory(zip_t *archive, char *directory_path, int entries_count, int *indexes)
{
    if (*directory_path == 0) {
        print_first_directory(archive, indexes, entries_count);
        return;
    }

    int i, k;

    for (i = 0; i < entries_count; i++) {
        const char *filename = zip_get_name(archive, i, 0);
        if (strncmp(directory_path, filename, strlen(directory_path)) == 0) {
            i++;
            break;
        }
    }

    printf("%s\n", directory_path);

    for (k = 1; i < entries_count; i++) {
        const char *filename = zip_get_name(archive, i, 0);

        if (strncmp(directory_path, filename, strlen(directory_path)) == 0) {
            char *ptr = strchr(filename + strlen(directory_path), '/');
            if (ptr == NULL || *(ptr + 1) == 0) {
                printf("%d: %s\n", k, filename + strlen(directory_path));
                indexes[k - 1] = i;
                k++;
            }
        } else
            break;
    }
}

void ziply_browse(void)
{
    puts("browse");
    printf("zip_file: %s\nargument: %s\n", ZipObject.path_zip_file, ZipObject.argument);

    int err;
    zip_t *zip = zip_open(ZipObject.path_zip_file, 0, &err);
    if (!zip) {
        fprintf(stderr, "can't open ZIP_FILE: %s\n", ZipObject.path_zip_file);
        exit(1);
    }

    /* check if zip archive is encrypted */
    struct zip_stat stat;
    if (zip_stat_index(zip, 0, ZIP_FL_UNCHANGED, &stat) == -1) {
        puts("error");
    }

    if (stat.encryption_method) {
        printf("encryption methode is supported\n");
        if (ZipObject.argument == NULL) {
            fprintf(stderr, "can't open ZIP_FILE: %s it's encrypted\nplease use the -p option\n", ZipObject.path_zip_file);
            return;
        } else 
            zip_set_default_password(zip, ZipObject.argument);
    }


    int num_files = zip_get_num_entries(zip, ZIP_FL_UNCHANGED);
    printf("Numbers of Files in ZIP-ARCHIV: %d\n", num_files);

    int indexes[num_files];

    print_first_directory(zip, indexes, num_files);

    char c = 0;
    int index = 0;
    char *current_directory;
    while (1) {
        char input[10];
        scanf("%s", input);
        if (strlen(input) > 1) {
            sscanf(input, "%c%d", &c, &index);
        } else {
            sscanf(input, "%c", &c);
        }

        /* Open File */
        if (c == 'o') {
            zip_file_t *zip_file = zip_fopen_index_encrypted(zip, indexes[index - 1], ZIP_FL_UNCHANGED, NULL);
            char buffer[5000] = { 0 };
            zip_fread(zip_file, buffer, 5000);
            printf("%s\n", buffer);
        }
        /* Visit Directory */
        if (c == 'v') {
            directory_change(&current_directory, zip_get_name(zip, indexes[index - 1], 0));
            print_directory(zip, current_directory, num_files, indexes);
            /*
            char *dir_name = zip_get_name(zip, indexes[index - 1], 0);

            for (i = 0; i < num_files; i++) {
                const char *filename = zip_get_name(zip, i, 0);
                if (strncmp(dir_name, filename, strlen(dir_name)) == 0) {
                    i++;
                    break;
                }
            }

            printf("%s\n", dir_name);

            for (k = 1; i < num_files; i++) {
                const char *filename = zip_get_name(zip, i, 0);

                if (strncmp(dir_name, filename, strlen(dir_name)) == 0) {
                    char *ptr = strchr(filename + strlen(dir_name), '/');
                    if (ptr == NULL || *(ptr + 1) == 0) {
                        printf("%d: %s\n", k, filename + strlen(dir_name));
                        indexes[k - 1] = i;
                        k++;
                    }
                } else
                    break;
            }
            */
        }

        if (c == 'b') {
            directory_back(&current_directory);
            print_directory(zip, current_directory, num_files, indexes);
            free(current_directory);
        }

        if (c == 'e') {
            /* zip file open */
            const char *name = zip_get_name(zip, indexes[index - 1], 0);
            printf("%s\n", name);

            zip_stat_t zip_stat;
            char path[150] = { 0 };
            int i;
            if (name[strlen(name) - 1] == '/') {
                for (i = 0; i < num_files; i++) {
                    strcpy(path, ".");
                    zip_stat_index(zip, i, 0, &zip_stat);
                    printf("%s\n", zip_stat.name);
                    if (strncmp(name, zip_stat.name, strlen(name)) == 0) {
                        int len = strlen(zip_stat.name);
                        strcat(path, "/");
                        strcat(path, zip_stat.name);
                        if (zip_stat.name[len - 1] == '/') {
                            printf("D-Path: %s\n", path);
                            mkdir(path, 0777);
                        } else {
                            printf("F-Path: %s\n", path);
                            zip_file_t *zip_file = zip_fopen_index(zip, i, 0);
                            char buffer[50] = { 0 };
                            FILE *f = fopen(path, "w+");
                            unsigned int bytes;
                            while ((bytes = zip_fread(zip_file, buffer, 50)) > 0) {
                                fwrite(buffer, 1, bytes, f);
                            }
                            fclose(f);
                            zip_fclose(zip_file);
                        }
                    }
                }
            } else {
                for (i = strlen(name); name[i] != '/'; i--) {
                    if (i == 0)
                        break;
                }

                strcpy(path, "./");
                strcat(path, name + i + ((i == 0) ? 0 : 1));

                printf("F-Path: %s\n", path);
                zip_file_t *zip_file = zip_fopen_index(zip, i, 0);
                char buffer[50] = { 0 };
                FILE *f = fopen(path, "w+");
                unsigned int bytes;
                while ((bytes = zip_fread(zip_file, buffer, 50)) > 0) {
                    fwrite(buffer, 1, bytes, f);
                }
                fclose(f);
                zip_fclose(zip_file);
            }

                /*
                int len = strlen(zip_stat.name);
                strcat(path, "/");
                strcat(path, zip_stat.name);
                if (zip_stat.name[len - 1] == '/') {
                    printf("D-Path: %s\n", path);
                    mkdir(path, 0777);
                } else {
                    printf("F-Path: %s\n", path);
                    zip_file_t *zip_file = zip_fopen_index(zip_archive, i, 0);
                    char buffer[50] = { 0 };
                    FILE *f = fopen(path, "w+");
                    unsigned int bytes;
                    while ((bytes = zip_fread(zip_file, buffer, 50)) > 0) {
                        fwrite(buffer, 1, bytes, f);
                    }
                    fclose(f);
                    zip_fclose(zip_file);
                }
                */
        }

        if (c == 'q') {
            exit(0);
        }
    }


    zip_close(zip);
}

bool zip_archive_password_check(zip_t *zip_archive, char *password)
{
    zip_set_default_password(zip_archive, password);

    if (zip_fopen_index_encrypted(zip_archive, 0, ZIP_FL_UNCHANGED, NULL) != NULL) {
        return true;
    }

    return false;
}

void ziply_bruteforce(void)
{
    puts("bruteforce");
    printf("zip_file: %s\nargument: %s\n", ZipObject.path_zip_file, ZipObject.argument);

    if (ZipObject.argument == NULL) {
    } else {
        int err;
        zip_t *zip = zip_open(ZipObject.path_zip_file, 0, &err);
        if (!zip) {
            fprintf(stderr, "can't open ZIP_FILE: %s\n", ZipObject.path_zip_file);
            exit(1);
        }

        /* check if zip archive is encrypted */
        struct zip_stat stat;
        if (zip_stat_index(zip, 0, ZIP_FL_UNCHANGED, &stat) == -1) {
            puts("error");
        }

        if (stat.encryption_method) {
            printf("encryption methode is supported\n");
            if (ZipObject.argument == NULL) {
                fprintf(stderr, "can't open ZIP_FILE: %s it's encrypted\nplease use the -p option\n", ZipObject.path_zip_file);
                return;
            } else 
                zip_set_default_password(zip, ZipObject.argument);
        }

        FILE *dictionary_file = fopen(ZipObject.argument, "r");
        char buffer[100];
        while (fgets(buffer, 100, dictionary_file)) {
            buffer[strlen(buffer) - 1] = 0;
            if (zip_archive_password_check(zip, buffer)) {
                printf("password was found %s\n", buffer);
                fclose(dictionary_file);
                zip_close(zip);
                return;
            }
        }
        printf("password was not found");

        fclose(dictionary_file);
        zip_close(zip);

    }
}

void ziply_password(void)
{
    puts("password");
    printf("zip_file: %s\nargument: %s\n", ZipObject.path_zip_file, ZipObject.argument);

    int err;
    zip_t *zip_archive = zip_open(ZipObject.path_zip_file, 0, &err);
    if (!zip_archive) {
        fprintf(stderr, "can't open ZIP_FILE: %s\n", ZipObject.path_zip_file);
        exit(1);
    }

    zip_set_default_password(zip_archive, ZipObject.argument);
    printf("%s\n", ZipObject.argument);

    if (zip_fopen_index_encrypted(zip_archive, 0, ZIP_FL_UNCHANGED, NULL) != NULL) {
        puts("right password");
    } else {
        puts("wrong password");
        return;
    }

    zip_close(zip_archive);

    ziply_browse();
}

void ziply_extract(void)
{
    /* argument if */
    struct stat st;
    if (stat(ZipObject.argument, &st) == -1) {
        int result = mkdir(ZipObject.argument, 0777);

        if (result == 0) {
            puts("folder created");
        } else {
            puts("failed createdion");
        }

    }

    int err;
    zip_t *zip_archive = zip_open(ZipObject.path_zip_file, 0, &err);
    int entries_count = zip_get_num_entries(zip_archive, ZIP_FL_UNCHANGED);

    zip_stat_t zip_stat;


    int i;
    char path[150];
    for (i = 0; i < entries_count; i++) {
        strcpy(path, ZipObject.argument);
        zip_stat_index(zip_archive, i, 0, &zip_stat);

        int len = strlen(zip_stat.name);
        strcat(path, "/");
        strcat(path, zip_stat.name);
        if (zip_stat.name[len - 1] == '/') {
            printf("D-Path: %s\n", path);
            mkdir(path, 0777);
        } else {
            printf("F-Path: %s\n", path);
            zip_file_t *zip_file = zip_fopen_index(zip_archive, i, 0);
            char buffer[50] = { 0 };
            FILE *f = fopen(path, "w+");
            unsigned int bytes;
            while ((bytes = zip_fread(zip_file, buffer, 50)) > 0) {
                fwrite(buffer, 1, bytes, f);
            }
            fclose(f);
            zip_fclose(zip_file);
        }
    }
    zip_close(zip_archive);
}

bool is_directory(char *path)
{
    struct stat st;
    if (stat(path, &st) == -1) {

    }

    if (st.st_mode & S_IFDIR)
        return true;

    return false;
}

void zip_archive_add_file(zip_t *zip_archive, char *path)
{
    zip_source_t *source = zip_source_file(zip_archive, path, 0, 0);
    if (zip_file_add(zip_archive, path, source, ZIP_FL_ENC_UTF_8) == -1)
        puts("zip_file_add error");
}

void zip_archive_add_directory(zip_t *zip_archive, char *path)
{
    int len = strlen(path);
    if (path[len - 1] == '/')
        path[len - 1] = 0;

    if (zip_dir_add(zip_archive, "inc", ZIP_FL_ENC_UTF_8) == - 1)
        puts("zip_dir_add error");

    struct dirent *dir_ptr;
    DIR *dir = opendir(path);
    char tem_path[150] = { 0 };
    while ((dir_ptr = readdir(dir)) != NULL) {
        if (dir_ptr->d_name[0] == '.')
            continue;

        strcpy(tem_path, path);
        strcat(tem_path, "/");
        strcat(tem_path, dir_ptr->d_name);
        if (is_directory(tem_path)) {
            printf("d-%s\n", tem_path);
            zip_archive_add_directory(zip_archive, tem_path);
            continue;
        }

        zip_archive_add_file(zip_archive, tem_path);
    }
}

void ziply_include(void)
{
    puts("include");
    printf("zip_file: %s\nargument: %s\n", ZipObject.path_zip_file, ZipObject.argument);

    int err;
    zip_t *zip_archive = zip_open(ZipObject.path_zip_file, 0, &err);

    if (is_directory(ZipObject.argument))
        zip_archive_add_directory(zip_archive, ZipObject.argument);
    else
        zip_archive_add_file(zip_archive, ZipObject.argument);

    zip_close(zip_archive);
}
