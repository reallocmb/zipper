#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Funktion zum Überprüfen, ob das Passwort korrekt ist
int checkPassword(char* password) {
    // Hier kannst du deine eigene Logik für die Überprüfung des Passworts einfügen
    // Gib 1 zurück, wenn das Passwort korrekt ist, andernfalls 0
    // Zum Beispiel:
    char* targetPassword = "Codeislife_3";
    return (strcmp(password, targetPassword) == 0);
}

// Funktion zum Durchführen des Brute-Force-Angriffs
void bruteForce(char* charset, int maxLength) {
    int charsetLength = strlen(charset);

    // Speicher für das aktuell zu überprüfende Passwort
    char* currentPassword = (char*) malloc((maxLength + 1) * sizeof(char));
    memset(currentPassword, 0, (maxLength + 1) * sizeof(char));

    int* indices = (int*) malloc(maxLength * sizeof(int));
    memset(indices, 0, maxLength * sizeof(int));

    int found = 0;

    while (!found) {
        // Aktuelles Passwort ausgeben (zum Debugging)
        printf("Trying password: %s\n", currentPassword);

        // Überprüfen, ob das aktuelle Passwort korrekt ist
        if (checkPassword(currentPassword)) {
            printf("Password found: %s\n", currentPassword);
            found = 1;
            break;
        }

        // Indices aktualisieren
        int carry = 1;
        int i = maxLength - 1;

        while (carry && i >= 0) {
            indices[i] = (indices[i] + 1) % charsetLength;
            carry = (indices[i] == 0);
            i--;
        }

        // Aktuelles Passwort aktualisieren
        for (int j = 0; j < maxLength; j++) {
            currentPassword[j] = charset[indices[j]];
        }
    }

    free(indices);
    free(currentPassword);
}

int main() {
    char charset[] = "Cabcdefghijklmnopqrstuvwxyz_3";  // Zeichensatz für das Brute-Force
    int maxLength = 12;  // Maximale Passwortlänge

    bruteForce(charset, maxLength);

    return 0;
}

